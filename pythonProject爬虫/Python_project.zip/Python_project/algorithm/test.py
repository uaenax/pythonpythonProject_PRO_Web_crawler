a = '2017-05-01 周一\t27°'
print(len(a))
print(a)
b = a[:13]
print(b)